


#include <stm32f0xx.h>
#include "STML.h"
#include "stepper.h"


#define TESTOWANIE_SILNIKA 0


// EKSPERYMENTALNIE WYZNACZONO, ŻE PODCZAS CHOWANIA GNIAZDKA SILNIK POWINIEN SPRAWDZIĆ OBECNOŚĆ WTYCZKI PO WYKONANIU 9378 KROKÓW
#define iloscKrokowDoSprawdzeniaWtyczki 9378
#define iloscKrokowDoSprawdzenia2 10000


// SZYBKOŚĆ SILNIKÓW (w krokach na sekundę)
uint16_t speed = 0.6 * 3398;


// CZAS OD STARTU CHOWANIA GNIAZDA DO SPRAWDZENIA, CZY SENSORY WYKRYWAJĄ WTYCZKĘ UWAGA, CO 200ms, czyli 200, 400 ... 4000, 4200, 4400
uint16_t czasSprawdzeniaWtyczki_ms = 4600;
// NIE POTRZEBA ŚREDNIKA

// to jest ac
uint16_t czasSprawdzenia2_ms = 4600;



// button wciśnięty = 1


stepper m1, m2;
#define button PB3
#define potSpeed PA7
#define potTime PA6

// KRAŃCÓWKI (limit switches)
#define ls1 PB5
#define ls2 PB4

// CZUJNIK NA ODLEGŁOŚĆ ODLEGŁOŚCI (contact sensor) zakryty = 0, dioda nie świeci = 0, dioda świeci = 1
#define cs1 PA2
#define cs2 PA1
#define cs3 PA11

// STEPPER 1 dir, step, enable
#define m1_d PA5
#define m1_s PA4
#define m1_e PA3


void initControls();


// wykonywane w równych odstępach czasu przez timer (osobny wątek na przerwaniach)
void updateSpeed() {
	ADC_setPin(potSpeed);
	speed = ADC_sample() / 4095.0 * 3398;
	stepper_setSpeed(m1, speed);
	czasSprawdzeniaWtyczki_ms = iloscKrokowDoSprawdzeniaWtyczki / speed * 1000;
	czasSprawdzenia2_ms = iloscKrokowDoSprawdzenia2 / speed * 1000;
}


//Jeżeli wywołana została funkcja release, to trzeba wywołać hold, bo inaczej nie pojedzie


#define chowajGniazdo() stepper_hold(m1);stepper_run(m1, -1e6, speed)
#define pokazGniazdo() stepper_hold(m1);stepper_run(m1, 1e6, speed)

#define zatrzymajGniazdo() stepper_run(m1, 0, 0);stepper_release(m1)


//ls1 krańcówka stykająca, kiedy wysunięte jest gniazdko
//ls2 styka kiedy gniazdko jest zasunięte
#define gniazdo_wysuniete io_isLow(ls1)  //Jeżeli to będzie 1, to gniazdko wysunięte
#define gniazdo_zasuniete io_isLow(ls2)  //Jeżeli to będzie 1, to gniazdko zasunięte

																							// WTYCZKI
#define wtyczka_wlozona 0
//(io_isLow(cs1) || io_isLow(cs2) || io_isLow(cs3))





//Gniazdo wysunięte k1 daje sygnał
//Gniazdo zasunięte k2 daje sygnał
//Gniazdo w podróży żadna nie daje sygnału



volatile float timeFromHidingStart_ms = 0;


int main() {
	CLOCK_internal48mhz();


	initControls();

	zatrzymajGniazdo();

	#if TESTOWANIE_SILNIKA
		int _lim = 255;
		int _bt = _lim;
		int _kierunek = 0; // 0: zatrzymany 1: przód 2: zatrzymany 3: tył
		while(1) {
			if(io_isHigh(button)) {
				if(_bt == _lim) {
					_kierunek = (_kierunek > 3) ? 0 : _kierunek + 1;
					switch(_kierunek) {
						case 0: zatrzymajGniazdo();break;
						case 1: pokazGniazdo();break;
						case 2: zatrzymajGniazdo();break;
						case 3: chowajGniazdo();break;
					}
				}
				_bt = 0;
			}
			if(_bt < _lim) _bt++;
		}
	#endif

	//stepper_hold(m1);stepper_run(m1, turn * 5000, speed);

	uint8_t sprawdzonoWtyczki = 0;
	uint8_t sprawdzono2 = 0;
	uint16_t lim = 30;
	uint16_t bt = lim;
	while(1) {

		// CHOWANIE GNIZDA
		if(io_isHigh(button) && gniazdo_wysuniete) { //Jeżeli przycisk jest wciśnięty (zbocze) i gniazdko wysunięte i jeżeli wtyczka nie jest włożona
			if(bt == lim) {
				timeFromHidingStart_ms = 0;
				sprawdzonoWtyczki = 0;
				chowajGniazdo();
				uint8_t przerwij = 0;
				while(!gniazdo_zasuniete) {	//poczekaj aż gniazdo się schowa
					for(int i = 0;i < 200;i++) {	// poczekaj 200ms, ale co milisekundę sprawdzając, czy już czas, aby sprawdzić obecność wtyczki
						if(timeFromHidingStart_ms >= czasSprawdzeniaWtyczki_ms) {
							if(!sprawdzonoWtyczki && wtyczka_wlozona) {
								pokazGniazdo();
								while(!gniazdo_wysuniete) delay_ms(200);             //poczekaj aż gniazdo się wysunie
								przerwij = 1;
								break;
							}
							sprawdzonoWtyczki = 1;
						}
						if(timeFromHidingStart_ms >= czasSprawdzenia2_ms) {
							if(!sprawdzono2 && wtyczka_wlozona) {
								pokazGniazdo();
								while(!gniazdo_wysuniete) delay_ms(200);             //poczekaj aż gniazdo się wysunie
								przerwij = 1;
								break;
							}
							sprawdzono2 = 1;
						}
						delay_ms(1);
						timeFromHidingStart_ms += 1;
					}
					if(przerwij) break;
				}
				zatrzymajGniazdo();
			}
			bt = 0;
		}

		// WYSUWANIE GNIAZDA
		else if(io_isHigh(button)) { //Jeżeli przycisk jest wciśnięty (zbocze) i gniazdko zasunięte
			if(bt == lim) {
				pokazGniazdo();
				while(!gniazdo_wysuniete) delay_ms(200);             //poczekaj aż gniazdo się wysunie
				zatrzymajGniazdo();
			}
			bt = 0;
		}

		if(bt < lim) bt++;
		delay_ms(10);
	}






}




void initControls() {

	//POT_SPEED
	ADC_init(potSpeed);

	//POT_TIME
	ADC_init(potTime);

	//BUTTON
	io_init(button.port);
	io_in(button, pullUp);

	//ls1
	io_init(ls1.port);
	io_in(ls1, pullUp);

	//ls2
	io_init(ls2.port);
	io_in(ls2, pullUp);

	//cs1
	io_init(cs1.port);
	io_in(cs1, pullUp);

	//cs2
	io_init(cs2.port);
	io_in(cs2, pullUp);


	//STEPPER MOTOR LIBRARY
	stepper_initTimer(TIM1, 20);


	//STEPPER MOTORS
	m1 = stepper_createMotor(m1_s, m1_d, m1_e);


	TIM_repeat(TIM3, 48000, 10, updateSpeed);


}













